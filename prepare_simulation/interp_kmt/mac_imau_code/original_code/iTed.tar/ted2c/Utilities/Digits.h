//  misc.h

int digit_in_column(int c, int number);

int count_digits(int number);

int remove_leading_digit(int number);

double  array_average(int n, double *v);

double array_product(int n, double *g, double *h);
